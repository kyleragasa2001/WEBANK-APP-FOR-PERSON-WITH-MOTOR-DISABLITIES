(function(window, undefined) {

  var jimLinks = {
    "bb1c4755-0e16-4bde-a824-cd6762cdc766" : {
    },
    "592809ae-2580-478c-a055-2ca40a4a9afd" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);