	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Path_1", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Path_3", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ["Battery full", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ["Wifi", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ["Alarm", "s-Path_5"]; 

	widgets.descriptionMap[["s-Ellipse_1", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ["Page control", "s-Group_2"]; 

	widgets.descriptionMap[["s-Ellipse_2", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ["Page control", "s-Group_2"]; 

	widgets.descriptionMap[["s-Ellipse_3", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "bb1c4755-0e16-4bde-a824-cd6762cdc766"]] = ["Page control", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_1", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Path_3", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Battery full", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Wifi", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alarm", "s-Path_5"]; 

	widgets.descriptionMap[["s-Rectangle_13", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_7"]; 

	widgets.descriptionMap[["s-Paragraph_13", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_7"]; 

	widgets.descriptionMap[["s-Paragraph_14", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_7"]; 

	widgets.descriptionMap[["s-Rectangle_14", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_7"]; 

	widgets.descriptionMap[["s-Paragraph_15", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_7"]; 

	widgets.descriptionMap[["s-Rectangle_15", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_8"]; 

	widgets.descriptionMap[["s-Paragraph_16", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_8"]; 

	widgets.descriptionMap[["s-Paragraph_17", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_8"]; 

	widgets.descriptionMap[["s-Rectangle_16", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_8"]; 

	widgets.descriptionMap[["s-Paragraph_18", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_8"]; 

	widgets.descriptionMap[["s-Rectangle_17", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_19", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_20", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_20", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_9"]; 

	widgets.descriptionMap[["s-Rectangle_18", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_21", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_21", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_9"]; 

	widgets.descriptionMap[["s-Rectangle_19", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_14", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Text_14", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_15", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Text_15", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_20", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_16", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Alert paired actions", "s-Group_4"]; 

	widgets.descriptionMap[["s-Panel_2", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "592809ae-2580-478c-a055-2ca40a4a9afd"]] = ["Stacked notification", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Path_1", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Path_3", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ["Battery full", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ["Wifi", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "50303821-c70b-451a-9e76-4b6e4d25b29e"]] = ["Alarm", "s-Path_5"]; 

	widgets.descriptionMap[["s-Rect_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Home indicator", "s-Rect_8"]; 

	widgets.descriptionMap[["s-Path_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Path_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Battery full", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Wifi", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Alarm", "s-Path_4"]; 

	