(function(window, undefined) {
  var dictionary = {
    "bb1c4755-0e16-4bde-a824-cd6762cdc766": "Sample Transaction",
    "592809ae-2580-478c-a055-2ca40a4a9afd": "CONTENT BAR",
    "50303821-c70b-451a-9e76-4b6e4d25b29e": "Login Screen",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "HOME SCREEN",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "Board 1"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);