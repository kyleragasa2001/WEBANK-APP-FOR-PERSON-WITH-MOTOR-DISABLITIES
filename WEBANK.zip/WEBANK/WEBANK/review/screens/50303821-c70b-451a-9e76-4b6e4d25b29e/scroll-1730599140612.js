(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    var older = jimUtil.loadScrollBars;
    jQuery.extend(jimUtil, {
        "loadScrollBars": function() {
        	if (older != undefined)
        		older();
            jQuery(".s-50303821-c70b-451a-9e76-4b6e4d25b29e .ui-page").overscroll({ showThumbs:false, direction:'none', roundCorners:false, backgroundColor:'', opacity:'', thickness:'', scrollSpacing:''});
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);